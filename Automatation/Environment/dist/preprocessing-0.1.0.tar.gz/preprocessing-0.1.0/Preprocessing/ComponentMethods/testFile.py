


def testFunction(message: str): 
    
    print(message)
    
    
    